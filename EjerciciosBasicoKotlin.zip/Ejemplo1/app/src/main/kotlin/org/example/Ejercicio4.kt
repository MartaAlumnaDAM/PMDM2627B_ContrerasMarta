/*
Ejercicio 4
Desarrolla un mini conversor de unidades de temperatura usando menu con when y repetición con do-while.

El programa mostrara estas opciones:

Celsius a Fahrenheit
Fahrenheit a Celsius
Salir

Requisitos:

Crea las funciones celsiusAFahrenheit y fahrenheitACelsius.
Crea una funcion leeNumero que lea un Double valido, lanzando una excepcion en caso contrario.
Mientras el usuario no elija salir, se debe pedir opcion y valor, mostrando el resultado.
Si la opcion no existe, se mostrara "Opcion no valida".
Una posible salida seria:

1) Celsius a Fahrenheit
2) Fahrenheit a Celsius
3) Salir
Elige opcion: 1
Introduce temperatura: 25
Resultado: 77.0 F
 */
package org.example

var c : Double = 0.0
var f : Double = 0.0

fun interactuaUsuario() {
    var opcion = 0

    while (opcion != 3) {

        do {
            println("Indique una opción: ")
            opcion = readln().toIntOrNull() ?: 0

            if (opcion !in 1..3) {
                println("Ingrese una opción válida.")
            }
        } while (opcion !in 1..3)


        if (opcion != 3) {
            println("Introduce la temperatura: ")
            val entrada = readln().toDoubleOrNull()


            if (entrada != null && leeNumero(entrada)) {
                when (opcion) {
                    1 -> println("Resultado: ${celsiusAFahrenheit(entrada)} °F")
                    2 -> println("Resultado: ${fahrenheitACelsius(entrada)} °C")
                }
            } else {
                println("Inserte una temperatura numérica válida.")
            }
        } else {
            println("Ha elegido salir... ¡Hasta pronto!")
        }
    }
}

fun celsiusAFahrenheit(c : Double) : Double{
    f = ((c * 9)/5) + 32
    return f
}

fun fahrenheitACelsius(f : Double) : Double{
    c = (f - 32) * (5.0/9.0)
    return c
}

fun leeNumero(numero : Any) : Boolean{
    return numero is Double;
}


